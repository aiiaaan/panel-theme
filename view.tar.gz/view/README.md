# RuangAdmin

RuangAdmin - Free Admin Control Panel Themes Based on Bootstrap 4

-------------------

**RuangAdmin** is responsive admin template. Based on Bootstrap 4 Framework. Highly cusmtomizable and easy to use. 

**You can review on [RuangAdmin - Demo](https://indrijunanda.github.io/RuangAdmin/)**

!["RuangAdmin Screenshot"](https://indrijunanda.github.io/RuangAdmin/img/screenshot/ss1.png "RuangAdmin Screenshot")

## Contribution 

Here is how : 

- Fork the repository
- Clone with ```git clone https://github.com/indrijunanda/RuangAdmin.git```
- Or Download zip


## Integrated

- **[CodeIgniter](https://github.com/Codeigniter-Template/Ruang-Admin-Template)**


## License

RuangAdmin is an open source and that is licensed under **[MIT](http://opensource.org/licenses/MIT)**



-------------------
### Cheers Up!

*Happy Developing and Learning* 💪



Regards 😁😁



