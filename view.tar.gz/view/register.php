<?php @mysql_connect("
fdb18.freehostingeu.com","3399926_mynigs","") or die ("could not connect to mysql"); @mysql_select_db("3399926_mynigs") or die ("no database"); ?>
<?php
echo $username;
 ?>


