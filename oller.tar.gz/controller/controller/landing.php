<?php

class Land extends Controller {

function In($f3) {
		if ($f3->exists('SESSION.id')) $f3->reroute('/home/admin/server');
		$f3->set('content','index.html');
	
	}


}
